AYE CHAN MYAT MON OO — BIRTHDAY WEBSITE

This website is personalized for Aye Chan Myat Mon Oo, with October 14 as the birthday.

PUBLISH WITH GITHUB PAGES (free):
1. Sign in to GitHub and create a new public repository, e.g. aye-chan-birthday.
2. Download and unzip this package.
3. Upload index.html to the root/main folder of the repository.
4. Open Settings → Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Select branch "main" and folder "/ (root)", then Save.
7. Wait a minute or two. The Pages section will show the published URL.
8. Open the URL on your phone to test it, then send the link to Aye Chan.

The website files are prepared, but this does not publish to your GitHub account automatically.
